<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>DreamTrip AI</title>
  <link rel="stylesheet" href="style.css">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
  <!-- HEADER -->
  <header>
    <h1>DreamTrip AI</h1>
    <p>Convierte tus sueños en viajes reales y personalizados</p>
  </header>

  <!-- MAIN -->
  <main>
    <!-- SECCIÓN DE ENTRADA DEL SUEÑO -->
    <section id="dream-input">
      <textarea id="dreamText" placeholder="Describe tu sueño..."></textarea>

      <select id="realityMode">
        <option value="fantasy">Fantástico</option>
        <option value="realistic">Realista</option>
        <option value="transformative">Transformador</option>
      </select>

      <select id="mood">
        <option value="neutral">Neutral</option>
        <option value="stressed">Estrés</option>
        <option value="excited">Emocionado</option>
      </select>

      <button id="generateBtn">Generar mi viaje soñado</button>
    </section>

    <!-- SECCIÓN DE RESULTADOS (oculta hasta usar botón) -->
    <section id="result" style="display:none;">
      <h2>Tu viaje soñado</h2>

      <!-- ET-DNA -->
      <div id="etdna">
        <h3>ET-DNA</h3>
        <canvas id="etdnaChart" width="400" height="200"></canvas>
      </div>

      <!-- Experiencia -->
      <div id="experience"></div>

      <!-- Micro-preview de tribu -->
      <div id="tribePreview"></div>
    </section>
  </main>

  <!-- FOOTER -->
  <footer>
    <p>DreamTrip AI - MVP Web Día 1</p>
  </footer>

  <script src="script.js"></script>
</body>
</html>
/* ===== ESTILOS GENERALES ===== */
body {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  padding: 0;
  background: linear-gradient(to bottom, #a2caff, #ffffff);
  color: #333;
}

header {
  text-align: center;
  padding: 2rem 1rem;
  background: rgba(255, 255, 255, 0.5);
}

header h1 {
  margin: 0.5rem 0;
}

main {
  max-width: 600px;
  margin: auto;
  padding: 1rem;
}

/* ===== TEXTAREA ===== */
textarea {
  width: 100%;
  height: 120px;
  padding: 0.5rem;
  font-size: 1rem;
  border-radius: 8px;
  border: 1px solid #aaa;
  margin-bottom: 1rem;
  resize: vertical;
}

/* ===== SELECT ===== */
select {
  width: 100%;
  padding: 0.5rem;
  font-size: 1rem;
  margin-bottom: 1rem;
  border-radius: 6px;
  border: 1px solid #aaa;
}

/* ===== BOTÓN ===== */
button {
  width: 100%;
  padding: 0.7rem;
  font-size: 1.1rem;
  background: #36a2eb;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  transition: 0.3s;
}

button:hover {
  background: #2580c1;
}

/* ===== RESULTADOS ===== */
#result {
  margin-top: 2rem;
  padding: 1rem;
  background: rgba(255, 255, 255, 0.8);
  border-radius: 8px;
}

#tribePreview {
  margin-top: 1rem;
  font-style: italic;
  color: #555;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 600px) {
  main {
    padding: 1rem;
  }

  button {
    font-size: 1rem;
  }
}
// ================== CONFIG ==================
const ET_DNA_DIMENSIONS = ["Freedom", "Introspection", "Exploration", "Rest", "Connection", "Transformation"];
const MAX_ET_DNA_HISTORY = 5;

// ================== ELEMENTOS DOM ==================
const dreamText = document.getElementById("dreamText");
const realityMode = document.getElementById("realityMode");
const mood = document.getElementById("mood");
const generateBtn = document.getElementById("generateBtn");

const resultSection = document.getElementById("result");
const experienceDiv = document.getElementById("experience");
const tribeDiv = document.getElementById("tribePreview");
const etdnaChartCtx = document.getElementById("etdnaChart").getContext("2d");

// ================== STORAGE ==================
function loadETDNAHistory() {
  return JSON.parse(localStorage.getItem("etdnaHistory") || "[]");
}

function saveETDNAHistory(profile) {
  const history = loadETDNAHistory();
  history.push(profile);
  if (history.length > MAX_ET_DNA_HISTORY) history.shift();
  localStorage.setItem("etdnaHistory", JSON.stringify(history));
}

// ================== GENERAR ET-DNA SIMULADO ==================
function generateRandomETDNA() {
  const profile = {};
  ET_DNA_DIMENSIONS.forEach(dim => {
    profile[dim] = Math.floor(Math.random() * 101); // 0-100
  });
  return profile;
}

// ================== MICRO-PREVIEW DE TRIBU ==================
function generateTribePreview() {
  const randomNumber = Math.floor(Math.random() * 200) + 50;
  return `<p>Otras ${randomNumber} personas con perfil similar están planeando viajes a Nueva Zelanda este año. <a href="#">Ver experiencias</a></p>`;
}

// ================== RENDERIZAR GRÁFICO ==================
let etdnaChart;
function renderETDNAChart(profile) {
  const labels = ET_DNA_DIMENSIONS;
  const data = labels.map(dim => profile[dim]);

  if (etdnaChart) etdnaChart.destroy();

  etdnaChart = new Chart(etdnaChartCtx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'ET-DNA Actual',
        data: data,
        backgroundColor: 'rgba(54, 162, 235, 0.6)'
      }]
    },
    options: { scales: { y: { beginAtZero: true, max: 100 } } }
  });
}

// ================== BOTÓN GENERAR ==================
generateBtn.addEventListener("click", () => {
  const dream = dreamText.value.trim();
  if (!dream) return alert("Por favor escribe tu sueño.");

  // Generar ET-DNA simulado
  const etdnaProfile = generateRandomETDNA();

  // Guardar en historial
  saveETDNAHistory(etdnaProfile);

  // Mostrar Experience-first (placeholder por ahora)
  experienceDiv.innerHTML = `
    <h3>Experience-first:</h3>
    <p>Basado en tu sueño, sugerimos un viaje único que conecte con tus emociones. Aquí aparecerá el itinerario generado por IA.</p>
  `;

  // Mostrar micro-preview de tribu
  tribeDiv.innerHTML = generateTribePreview();

  // Renderizar gráfico ET-DNA
  renderETDNAChart(etdnaProfile);

  // Mostrar sección de resultados
  resultSection.style.display = "block";
});
// ================== CONFIG ==================
const ET_DNA_DIMENSIONS = ["Freedom", "Introspection", "Exploration", "Rest", "Connection", "Transformation"];
const MAX_ET_DNA_HISTORY = 5;

// ================== ELEMENTOS DOM ==================
const dreamText = document.getElementById("dreamText");
const realityMode = document.getElementById("realityMode");
const mood = document.getElementById("mood");
const generateBtn = document.getElementById("generateBtn");

const resultSection = document.getElementById("result");
const experienceDiv = document.getElementById("experience");
const tribeDiv = document.getElementById("tribePreview");
const etdnaChartCtx = document.getElementById("etdnaChart").getContext("2d");

// ================== STORAGE ==================
function loadETDNAHistory() {
  return JSON.parse(localStorage.getItem("etdnaHistory") || "[]");
}

function saveETDNAHistory(profile) {
  const history = loadETDNAHistory();
  history.push(profile);
  if (history.length > MAX_ET_DNA_HISTORY) history.shift();
  localStorage.setItem("etdnaHistory", JSON.stringify(history));
}

// ================== MICRO-PREVIEW DE TRIBU ==================
function generateTribePreview() {
  const randomNumber = Math.floor(Math.random() * 200) + 50;
  return `<p>Otras ${randomNumber} personas con perfil similar están planeando viajes a Nueva Zelanda este año. <a href="#">Ver experiencias</a></p>`;
}

// ================== RENDERIZAR GRÁFICO ==================
let etdnaChart;
function renderETDNAChart(profile) {
  const labels = ET_DNA_DIMENSIONS;
  const data = labels.map(dim => profile[dim]);

  if (etdnaChart) etdnaChart.destroy();

  etdnaChart = new Chart(etdnaChartCtx, {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'ET-DNA Actual',
        data: data,
        backgroundColor: 'rgba(54, 162, 235, 0.6)'
      }]
    },
    options: { scales: { y: { beginAtZero: true, max: 100 } } }
  });
}

// ================== FETCH GPT-4o-mini ==================
async function fetchDreamTripAI(dream, reality, mood) {
  const prompt = `
Eres DreamTrip AI, un motor que convierte sueños en viajes reales.

Entrada:
- Sueño: "${dream}"
- Reality Mode: ${reality}
- Mood: ${mood}

Salida esperada (JSON):
{
  "ET_DNA": {
    "Freedom": <0-100>,
    "Introspection": <0-100>,
    "Exploration": <0-100>,
    "Rest": <0-100>,
    "Connection": <0-100>,
    "Transformation": <0-100>
  },
  "Experience": "<Texto tipo itinerario inspirador, explicando por qué el destino encaja con el sueño y las emociones del usuario>"
}
  `;

  try {
    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer TU_API_KEY_AQUI"
      },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        input: prompt
      })
    });

    const data = await response.json();

    // Extraer JSON de la salida
    const content = data.output[0].content[0].text;
    return JSON.parse(content);

  } catch (error) {
    console.error("Error IA:", error);
    alert("Error generando viaje soñado. Revisa la consola.");
    return null;
  }
}

// ================== BOTÓN GENERAR ==================
generateBtn.addEventListener("click", async () => {
  const dream = dreamText.value.trim();
  if (!dream) return alert("Por favor escribe tu sueño.");

  const reality = realityMode.value;
  const userMood = mood.value;

  // Mostrar loading
  experienceDiv.innerHTML = `<p>Generando tu viaje soñado...</p>`;
  tribeDiv.innerHTML = "";

  // Llamada a IA
  const aiResult = await fetchDreamTripAI(dream, reality, userMood);
  if (!aiResult) return;

  // Guardar ET-DNA en historial
  saveETDNAHistory(aiResult.ET_DNA);

  // Mostrar Experience-first
  experienceDiv.innerHTML = `
    <h3>Experience-first:</h3>
    <p>${aiResult.Experience}</p>
  `;

  // Mostrar micro-preview de tribu
  tribeDiv.innerHTML = generateTribePreview();

  // Renderizar gráfico ET-DNA
  renderETDNAChart(aiResult.ET_DNA);

  // Mostrar sección de resultados
  resultSection.style.display = "block";
});
<h2>🌊 Estado emocional detectado</h2>
<div id="emotionalState"></div>

<h2>✨ Experiencia ideal para ti</h2>
<div id="experience"></div>

<h2>🗺️ Actividades simbólicas</h2>
<div id="activities"></div>

<h2>🌍 El lugar perfecto</h2>
<div id="destination"></div>

<h2>🧬 Tu Emotional Travel DNA</h2>
<div id="etdnaText"></div>
<canvas id="etdnaChart" class="hidden"></canvas>

<h2>👥 Tu tribu emocional</h2>
<div id="tribePreview"></div>
